const {models} = require('../models');

// Crear un  hospital
exports.create = async function (name, city) {
    try {
        // Creación de instancia no persistente de Hospital
        let hospital = models.Hospital.build({
            name,
            city
        });

        // Almacenar en DB:
        hospital = await hospital.save({fields: ["name", "city"]});
        console.log('Hospital: Hospital created successfully.');

        return hospital;
    
    } catch (error) {
        console.log('Error: Failed to create hospital: ' + error.message);
    }
};

// Devuelve todos los hospitales
exports.index = async function () {
    let hospitales = await models.Hospital.findAll();
    return hospitales;
}

// Filtra los hospitales por ciudad
exports.indexByCity = async function (cityParam) {
    let hospitales = await models.Hospital.findAll({
        where: {
            city: cityParam
        }
    });

    return hospitales;
}

