const {models} = require('../models');

// Muestra la informacion de un paciente
exports.read = async function (patientId) {
    let patient = await models.Patient.findByPk(patientId);
    
    return patient;
}

// Crea un paciente en un hospital
exports.create = async function (hospitalId, name, surname, dni) {
    try {
        // Creación de instancia no persistente de Paciente
        let patient = models.Patient.build({
            name,
            surname,
            dni,
            hospitalId: hospitalId
        });

        // Almacenar en DB:
        patient = await patient.save({fields: ["name", "surname", "dni", "hospitalId"]});
        console.log('Patient: Patient created successfully.');

        return patient;
    } catch (error) {
        console.log(error);
    }
}

// OPCIONAL - Devuelve todos los pacientes para asegurar que han sido creados correctamente en la DB.
exports.optionalIndex = async function () {
    let patients = await models.Patient.findAll();
    return patients;
}

// Actualiza un paciente
exports.update = async function (patientId, name, surname, dni) {
    let patient = await models.Patient.findByPk(patientId);

    patient.name = name;
    patient.surname = surname;
    patient.dni = dni;

    try {
        await patient.save({fields: ["name", "surname", "dni"]});
        console.log('Paciente editado exitosamente.');
    } catch (error) {
        console.log(error);
    }
}

// Borra un paciente
exports.delete = async function (patientId) {
    try {
        await models.Patient.destroy({ where: {
            id: patientId
        }});
        console.log('Paciente borrado exitosamente.');
    } catch (error) {
        console.log(error);
    }
}


// Buscar pacientes de un hospital ordenados por el nombre (de la A a la Z)
exports.indexByHospital = async function (hospitalId) {
    let patients = await models.Patient.findAll({
        order: [ "name" ],
        where: {
            hospitalId: hospitalId
        }
    });

    return patients;
}

// Buscar pacientes de un hospital ordenados por el nombre INVERSO (de la Z a la A)
exports.indexByHospitalDescending = async function (hospitalId) {
    let patients = await models.Patient.findAll({
        order: [
            ["name", "DESC"]
        ],
        where: {
            hospitalId: hospitalId
        }
    });

    return patients;
}