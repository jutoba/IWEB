const {models} = require('../models');

// Crear un doctor
exports.create = async function (name, surname, speciality) {
    try {
        // Creación de instancia no persistente de doctor
        let doctor = models.Doctor.build({
            name,
            surname,
            speciality
        });

        // Almacenar en DB:
        doctor = await doctor.save({fields: ["name", "surname", "speciality"]});
        console.log('Doctor: Doctor created successfully.');

        return doctor;

    } catch (error) {
        console.log(error);
    }
};

// OPCIONAL - Devuelve todos los doctores para asegurar que han sido creados correctamente en la DB.
exports.optionalIndex = async function () {
    let doctores = await models.Doctor.findAll();
    return doctores;
}

// Asigna un doctor y devuelve los datos del paciente
exports.assignDoctor = async function (patientId, doctorId) {
    let patient = await models.Patient.findByPk(patientId);
    let doctor = await models.Doctor.findByPk(doctorId);

    patient = await patient.addDoctor(doctor);

    return patient;
}

// Muestra los medicos de un paciente
exports.indexByPatient = async function (patientId) {
    let patient = await models.Patient.findByPk(patientId);
    let doctors = await patient.getDoctors();

    return doctors;
}
