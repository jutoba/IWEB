export default function Resultados(props) {
	return (<div id="resultados">
     <h2 id="timezone">Timezone: {props.items.timezone}</h2>
     <br/>
     <h2>El tiempo los próximos días será:</h2>
    <ul id="tarjetas">
      {props.items.daily.map((item, index) => (
        <li key={index}>   
          <p><b>{new Date(item.dt * 1000).toLocaleDateString()}</b></p>  
          <p><img className="tiempoimg" src={item.image} alt={"/"+item.weather[0].icon+"@2x.png"} /></p>     
          <p>Temp:{((item.temp.day)-273).toFixed(1)}ºC</p>
          <p>Humedad: {item.humidity}%</p>
          <p>Viento: {item.wind_speed}m/s</p>
        </li>
      )).slice(0,props.numitems)}
    </ul>

  </div>)
}