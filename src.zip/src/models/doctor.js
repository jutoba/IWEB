'use strict';

const {Model} = require('sequelize');

// Definición del modelo de Paciente:
module.exports = (sequelize, DataTypes) => {

    class Doctor extends Model { }

    Doctor.init({
        name: {
            type: DataTypes.STRING
        },
        surname: {
            type: DataTypes.STRING
        },
        speciality: {
            type: DataTypes.STRING
        }
    }, { sequelize });
    
    return Doctor;
};
