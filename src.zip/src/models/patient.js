'use strict';

const {Model} = require('sequelize');

// Definición del modelo de Paciente:
module.exports = (sequelize, DataTypes) => {

    class Patient extends Model { }

    Patient.init({
        name: {
            type: DataTypes.STRING
        },
        surname: {
            type: DataTypes.STRING
        },
        dni: {
            type: DataTypes.STRING
        },  
    }, { sequelize });
    
    return Patient;
};
