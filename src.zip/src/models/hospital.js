'use strict';

const {Model} = require('sequelize');

// Definición del modelo de Paciente:
module.exports = (sequelize, DataTypes) => {

    class Hospital extends Model { }

    Hospital.init({
        name: {
            type: DataTypes.STRING
        },
        city: {
            type: DataTypes.STRING
        }
    }, { sequelize });
    
    return Hospital;
};
