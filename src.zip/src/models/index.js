// Importar SEQUELIZE: Load ORM
const Sequelize = require('sequelize');

// To use SQLite data base:
// DATABASE_URL = sqlite:db-p5-orm.sqlite
const url = "sqlite:db-p5-orm.sqlite";

// CREACIÓN DB:
const sequelize = new Sequelize(url, { logging: false });

// IMPORTAR DEFINICIONES DE MODELOS:
const Patient = require('./patient')(sequelize, Sequelize.DataTypes);
const Hospital = require('./hospital')(sequelize, Sequelize.DataTypes);
const Doctor = require('./doctor')(sequelize, Sequelize.DataTypes);

// Relación 1-a-N entre Hospital y Paciente
Hospital.hasMany(Patient, {as: 'patient', foreignKey: 'hospitalId'});
Patient.belongsTo(Hospital, {as: 'hospital', foreignKey: 'hospitalId'});

// Relación N-a-M entre Doctor y Pacientes:
Doctor.belongsToMany(Patient, { through: 'Doctor_Patients' });
Patient.belongsToMany(Doctor, { through: 'Doctor_Patients' });

module.exports = sequelize;