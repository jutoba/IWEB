import { useState } from "react";
import './App.css';
import Errores from "./Errores";
import Header from "./Header";
import Resultados from "./Resultados";
import CONFIG from "./config/config";
import { mock1 } from "./constants/mock.js";


function App() {

  const [latitud, setLatitud] = useState(CONFIG.default_lat);
  const [longitud, setLongitud] = useState(CONFIG.default_lon);
  const [resultado, setResultado] = useState(null);
  const[errores,setErrores] = useState(null);


 
  const callServer = async (param) => {    
    if(CONFIG.use_server) {
      try {
        let queryparams = "";
        queryparams = "?lat=" + latitud + "&lon=" + longitud + "&appid=" + CONFIG.api_key;
        const response = await fetch(`${CONFIG.server_url}${queryparams}`);
        const data = await response.json();         
        if(response.status===200){
          setResultado(data);
        }else{
          const errorMensaje = {
            cod: response.status,
            message: response.statusText
          }; 
          setResultado(null);
          setErrores(errorMensaje);
        }
      }catch (e) {
        console.log(e);
        setResultado({ e: {description: e.message} });
      }
    } else {
      setResultado(mock1);
    }
  }

  return (
    <div className="App">
      <Header />
      <h2 id="titulo">El tiempo</h2>
      <div><input type="number" id="latitud" placeholder="Latitud a buscar"  value={latitud} onChange={(e) => setLatitud(e.target.value)}></input></div>
      <div><input type="number" id="longitud" placeholder="Longitud a buscar" value={longitud} onChange={(e) => setLongitud(e.target.value)}></input></div>
				<br/>
        <button id="buscar" className="new" onClick={()=>callServer()}>
          Buscar
        </button>  
        <div>
        {resultado && <Resultados numitems={CONFIG.num_items} items={resultado} />}
        {errores && <Errores numitems={errores}/>}
        </div>
    </div>
  );
}

export default App;